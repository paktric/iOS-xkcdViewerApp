//
//  xkcdViewerApp.swift
//  xkcdViewer
//
//  Created by student on 10/11/22.
//

import SwiftUI

@main
struct xkcdViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
